console.log('Node.js version:', process.version);
console.log('Node.js executable path:', process.execPath); 